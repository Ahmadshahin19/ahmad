# -*- coding: utf-8 -*-

##################################################################################################
##                                                                                              ##
## Copyright © 2025 Shahin Soft. All rights reserved.                                           ##
## This module is proprietary software of Shahin Soft and may not be redistributed, modified,   ##
## or used without explicit written permission from Shahin Soft.                                ##
##                                                                                              ##
## For inquiries or permissions, contact: shahin.soft.co@gmail.com                              ##
##                                                                                              ##
##################################################################################################

{
    "name": "Journal Entry Print",
    "version": "16.0.0.0",
    "depends": ['base', 'account'],
    "author": "Shahin Soft",
    "summary": "Journal Entry Print",
    "price": 20.00,
    "currency": 'USD',
    "category": 'Accounting/Accounting',
    "website": "https://www.youtube.com/@shahin_soft",
    "live_test_url": "https://www.youtube.com/@shahin_soft",
    "data": [
        'report/account_move_report.xml',
        'report/account_move_templates.xml',
    ],
    "auto_install": False,
    "installable": True,
    "application": False,
    "images": ['static/description/icon.png'],
    "license": 'OPL-1',
}
